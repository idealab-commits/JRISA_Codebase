#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
download_datasets.py

Downloads/prepares the three benchmarks used by the JRISA proposed method
(Section III-I of the manuscript):

    CREMI       -> Hugging Face ("MedOtter/CREMI") -- confirmed public mirror
    AC3/AC4     -> bossDB, via the `intern` client   -- confirmed public project
    MitoEM-R/H  -> Grand Challenge portal            -- NO public API; manual
                   registration + download is required (see instructions
                   printed by this script and written to a README in the
                   output folder).

IMPORTANT: this script does NOT fabricate download endpoints. CREMI and
AC3/AC4 use verified, real sources. MitoEM has no scriptable download path
as of this writing -- the script only prepares the expected folder layout
and prints/writes the manual steps.

Usage:
    python download_datasets.py --dataset all --output-dir ./data
    python download_datasets.py --dataset cremi --output-dir ./data
    python download_datasets.py --dataset ac3ac4 --output-dir ./data
    python download_datasets.py --dataset mitoem --output-dir ./data

Requirements (install only what you need):
    pip install huggingface_hub      # for CREMI
    pip install intern               # for AC3/AC4 (bossDB client)
"""
import argparse
import os
import sys
import zipfile
import tarfile
from pathlib import Path


# ---------------------------------------------------------------------------
# CREMI  (Hugging Face: MedOtter/CREMI)
# ---------------------------------------------------------------------------
def download_cremi(output_dir: Path):
    """Download the CREMI dataset from its confirmed Hugging Face mirror."""
    try:
        from huggingface_hub import snapshot_download
    except ImportError:
        print("[CREMI] 'huggingface_hub' is not installed.\n"
              "        Install it with: pip install huggingface_hub")
        sys.exit(1)

    dest = output_dir / "cremi"
    dest.mkdir(parents=True, exist_ok=True)

    print(f"[CREMI] Downloading MedOtter/CREMI from Hugging Face to {dest} ...")
    print("        (No HF token is required for this public dataset. If you "
          "have one set as the HF_TOKEN environment variable, it will be "
          "picked up automatically and can help avoid rate limits.)")

    local_path = snapshot_download(
        repo_id="MedOtter/CREMI",
        repo_type="dataset",
        local_dir=str(dest),
    )
    print(f"[CREMI] Downloaded to: {local_path}")

    _extract_archives_in(dest)
    print("[CREMI] Done. Expect volumes for CREMI A/B/C (raw + neuron/cleft labels).")


# ---------------------------------------------------------------------------
# AC3/AC4  (bossDB, via `intern`)
# ---------------------------------------------------------------------------
def download_ac3ac4(output_dir: Path):
    """Download the AC4 cutout from bossDB via the `intern` client.

    AC4's exact bossDB coordinate frame is confirmed from the project page
    (bossdb.org/project/kasthuri2015): channel 'bossdb://kasthuri2015/em/cc',
    extent [0:1024, 0:1024, 0:100] in (x, y, z) -> intern returns arrays in
    ZYX order.

    NOTE: AC3's exact channel/coordinate-frame name was NOT confirmed during
    research for this script (the project page lists several related
    collections -- 'em', 'ac4', 'connectomics2019_results', plus separate
    Neuroglancer links for '3Cylinder' and 'Kasthuri11' -- but does not
    unambiguously label one of them as "AC3"). Rather than guess a resource
    identifier, this function downloads the CONFIRMED AC4 cutout and prints
    a clear TODO for AC3 so you don't silently pull the wrong volume.
    Verify the correct AC3 channel name yourself at:
        https://bossdb.org/project/kasthuri2015
    (or by listing collections with `intern`'s `BossRemote` API), then fill
    in AC3_CHANNEL below.
    """
    try:
        from intern import array
    except ImportError:
        print("[AC3/AC4] 'intern' is not installed.\n"
              "           Install it with: pip install intern")
        sys.exit(1)

    dest = output_dir / "ac3_ac4"
    dest.mkdir(parents=True, exist_ok=True)

    # --- AC4: confirmed channel + coordinate frame ---
    print("[AC3/AC4] Fetching AC4 (confirmed channel 'bossdb://kasthuri2015/em/cc', "
          "extent 1024x1024x100) ...")
    try:
        import numpy as np
        channel = array("bossdb://kasthuri2015/em/cc")
        # intern slicing order is [z, y, x]
        ac4_data = channel[0:100, 0:1024, 0:1024]
        np.save(dest / "ac4_em.npy", ac4_data)
        print(f"[AC3/AC4] Saved AC4 EM volume to {dest / 'ac4_em.npy'} "
              f"(shape={ac4_data.shape})")
    except Exception as e:
        print(f"[AC3/AC4] AC4 download failed: {e}\n"
              "           This usually means bossDB anonymous access needs a "
              "public API token, or the channel name has changed. Check "
              "https://bossdb.org/project/kasthuri2015 for current access "
              "instructions ('For anonymous read-only access to BossDB...').")

    # --- AC3: NOT confirmed -- do not guess, tell the user what to do ---
    AC3_CHANNEL = None  # <-- fill this in yourself, e.g. "bossdb://kasthuri2015/<verified_channel>/cc"
    if AC3_CHANNEL is None:
        print("\n[AC3/AC4] AC3 channel not configured (see this function's docstring).\n"
              "           1. Visit https://bossdb.org/project/kasthuri2015\n"
              "           2. Identify the correct AC3 collection/channel name\n"
              "              (it is NOT the same as the 'ac4' channel used above).\n"
              "           3. Set AC3_CHANNEL in this script and re-run:\n"
              "              python download_datasets.py --dataset ac3ac4 --output-dir ./data\n")
    else:
        import numpy as np
        channel = array(AC3_CHANNEL)
        ac3_data = channel[0:256, 0:1024, 0:1024]
        np.save(dest / "ac3_em.npy", ac3_data)
        print(f"[AC3/AC4] Saved AC3 EM volume to {dest / 'ac3_em.npy'} "
              f"(shape={ac3_data.shape})")

    print("[AC3/AC4] NOTE: this fetches raw EM only. Instance/synapse ground-truth "
          "annotations (needed for the BCD label generation in Section III-F) "
          "are a SEPARATE channel/collection on bossDB -- check the project's "
          "'View Metadata' / collections list for the annotation channel name.")


# ---------------------------------------------------------------------------
# MitoEM-R/H  (no public API -- manual download)
# ---------------------------------------------------------------------------
MITOEM_README = """\
MitoEM-R/H — manual download required
======================================

No public, scriptable download endpoint exists for MitoEM as of this
writing. The dataset is distributed through the challenge portal, which
requires registration:

    https://mitoem.grand-challenge.org/

Steps:
    1. Create a Grand Challenge account and register for the MitoEM challenge.
    2. Follow the portal's data-access instructions to download the two
       volumes:
           - Mito-R (rat cortex)
           - Mito-H (human cortex)
    3. Place the downloaded volumes into this folder using the layout below
       (the rest of the JRISA codebase expects this structure):

        data/mitoem/
        +-- mito_r/
        |   +-- im/           # raw EM image stack
        |   +-- mito-labels/  # instance labels (if released for your split)
        +-- mito_h/
            +-- im/
            +-- mito-labels/

    4. Note: MitoEM-R/H is used ONLY as a zero-shot generalization test in
       this pipeline (Section III-I) -- it is never trained on. You need it
       populated before running evaluate.py's generalization pass, but not
       before train.py.

A related, newer resource ("MitoEM 2.0") was also announced as a curated,
multi-species mitochondria instance-segmentation benchmark; if the original
MitoEM portal is unavailable, check whether MitoEM 2.0 supersedes it and
adjust this pipeline's dataset loader accordingly.
"""


def prepare_mitoem(output_dir: Path):
    dest = output_dir / "mitoem"
    (dest / "mito_r" / "im").mkdir(parents=True, exist_ok=True)
    (dest / "mito_r" / "mito-labels").mkdir(parents=True, exist_ok=True)
    (dest / "mito_h" / "im").mkdir(parents=True, exist_ok=True)
    (dest / "mito_h" / "mito-labels").mkdir(parents=True, exist_ok=True)

    readme_path = dest / "README_MANUAL_DOWNLOAD.txt"
    readme_path.write_text(MITOEM_README, encoding="utf-8")

    print(f"[MitoEM] No public API available -- created expected folder layout at {dest}")
    print(f"[MitoEM] Manual download instructions written to: {readme_path}")
    print(MITOEM_README)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def _extract_archives_in(folder: Path):
    """Extract any .zip/.tar/.tar.gz files found directly inside `folder`."""
    for item in list(folder.rglob("*")):
        if item.suffix == ".zip":
            print(f"  extracting {item.name} ...")
            with zipfile.ZipFile(item, "r") as zf:
                zf.extractall(item.parent)
        elif item.suffixes[-2:] == [".tar", ".gz"] or item.suffix == ".tgz":
            print(f"  extracting {item.name} ...")
            with tarfile.open(item, "r:gz") as tf:
                tf.extractall(item.parent)
        elif item.suffix == ".tar":
            print(f"  extracting {item.name} ...")
            with tarfile.open(item, "r:") as tf:
                tf.extractall(item.parent)


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------
def main():
    parser = argparse.ArgumentParser(description=__doc__,
                                      formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--dataset", choices=["cremi", "ac3ac4", "mitoem", "all"],
                         default="all", help="Which dataset(s) to fetch/prepare.")
    parser.add_argument("--output-dir", type=str, default="./data",
                         help="Root output directory (default: ./data)")
    args = parser.parse_args()

    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    if args.dataset in ("cremi", "all"):
        download_cremi(output_dir)
    if args.dataset in ("ac3ac4", "all"):
        download_ac3ac4(output_dir)
    if args.dataset in ("mitoem", "all"):
        prepare_mitoem(output_dir)

    print("\nAll requested dataset steps complete. See per-dataset messages above "
          "for any manual follow-up required.")


if __name__ == "__main__":
    main()
